document.querySelector( selectors:'#contact form sublim')
.addEventlistener(type'click', listener: function (event)
{
  event.preventDefault()
 
  let nameInput: document.getElementbyId(elementid:'name')
  console.log(nameInput)
  
}
)
{}