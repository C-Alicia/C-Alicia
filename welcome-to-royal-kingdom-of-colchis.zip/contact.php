    <section id="contact">
      <form id="contact" method="post" action="contact.php">
          <label for="name">Name:</label><br>
          <input type="text" id="name" name="name" value="Enter your name"><br>
         
          <label for="email">Email:</label><br>
          <input type="email" id="email" name="email"value="Enter your mail"><br>
          
          <label for="message">Message:</label><br>
          <textarea id="message" name="message" value="Enter your message"style="height:200px"></textarea>
        
          <input type="submit" value="Submit">
      </form>
     </section>
    
    <script src="("script.js"></script>
    </body>
</html>